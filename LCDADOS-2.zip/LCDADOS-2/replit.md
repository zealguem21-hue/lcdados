# replit.md

## Overview

This is a full-stack web application for **LC Dados**, a Portuguese data analytics and software consulting company. The application serves as a corporate website featuring a landing page with multiple sections including hero, consulting services, workflow process, technology stack showcase, recruitment information, and contact form.

The project follows a monorepo structure with a React frontend and Express backend, designed to showcase the company's data analytics and software development services.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **State Management**: TanStack React Query for server state
- **Styling**: Tailwind CSS with CSS variables for theming
- **UI Components**: shadcn/ui component library (Radix UI primitives with custom styling)
- **Build Tool**: Vite with React plugin

The frontend is organized as a single-page application with section-based navigation. The main page (`ElementLight.tsx`) composes multiple section components that represent different parts of the landing page. Navigation uses smooth scrolling to anchor points rather than traditional route changes.

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **HTTP Server**: Node.js native `http` module wrapping Express
- **Development**: TSX for TypeScript execution, Vite middleware for HMR
- **Production**: esbuild bundles the server, static files served from `dist/public`

The backend follows a simple architecture with:
- `server/index.ts`: Entry point with Express middleware setup
- `server/routes.ts`: API route definitions (currently minimal, prefixed with `/api`)
- `server/storage.ts`: Data access layer with interface-based storage abstraction
- `server/vite.ts`: Development server setup with Vite integration

### Data Storage
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: PostgreSQL (Neon serverless)
- **Schema**: Defined in `shared/schema.ts` using Drizzle's table builders
- **Validation**: Zod schemas generated from Drizzle schemas via `drizzle-zod`
- **Current Implementation**: In-memory storage (`MemStorage` class) as default, with interface ready for database implementation

The storage layer uses an interface pattern (`IStorage`) allowing easy swapping between in-memory storage for development and PostgreSQL for production.

### Project Structure
```
├── client/           # Frontend React application
│   ├── src/
│   │   ├── components/ui/  # shadcn/ui components
│   │   ├── pages/          # Page components and sections
│   │   ├── hooks/          # Custom React hooks
│   │   └── lib/            # Utilities and query client
├── server/           # Backend Express application
├── shared/           # Shared code (schema, types)
├── migrations/       # Drizzle database migrations
└── attached_assets/  # Static assets referenced in code
```

### Path Aliases
- `@/*` → `./client/src/*`
- `@shared/*` → `./shared/*`
- `@assets` → `./attached_assets`

## External Dependencies

### Database
- **Neon Database**: PostgreSQL serverless database via `@neondatabase/serverless`
- **Connection**: Requires `DATABASE_URL` environment variable
- **Session Store**: `connect-pg-simple` available for session persistence

### UI Framework
- **Radix UI**: Complete set of accessible, unstyled primitives
- **Lucide React**: Icon library
- **Embla Carousel**: Carousel functionality
- **Vaul**: Drawer component
- **cmdk**: Command palette component
- **React Day Picker**: Calendar/date picker
- **Recharts**: Charting library (available but not currently used)

### Form Handling
- **React Hook Form**: Form state management
- **@hookform/resolvers**: Zod resolver for validation
- **Zod**: Schema validation

### Development Tools
- **Replit Plugins**: 
  - `@replit/vite-plugin-runtime-error-modal`: Error overlay
  - `@replit/vite-plugin-cartographer`: Dev tooling (dev only)
  - `@replit/vite-plugin-dev-banner`: Development banner (dev only)

### Build Tools
- **Vite**: Frontend bundling and dev server
- **esbuild**: Server bundling for production
- **Drizzle Kit**: Database migration tooling