export const JoinUsSection = (): JSX.Element => {
  const technologies = [
    {
      image: "/figmaAssets/image-2.png",
      label: "PYTHON",
      imageWidth: "w-[115px]",
      imageHeight: "h-[34px]",
      containerWidth: "w-[167px]",
    },
    {
      image: "/figmaAssets/image-3.png",
      label: "PANDAS",
      imageWidth: "w-[114px]",
      imageHeight: "h-[46.13px]",
      containerWidth: "w-[172px]",
    },
    {
      image: "/figmaAssets/image-4.png",
      label: "STREAMLIT",
      imageWidth: "w-[123px]",
      imageHeight: "h-[34px]",
      containerWidth: "w-[123px]",
    },
    {
      image: "/figmaAssets/image-5.png",
      label: "SQL",
      imageWidth: "w-[62px]",
      imageHeight: "h-[29px]",
      containerWidth: "w-[62px]",
    },
    {
      image:
        "/figmaAssets/microsoft-excel-microsoft-project-logo-microsoft-word-excel-296c.png",
      label: "EXCEL",
      imageWidth: "w-[73px]",
      imageHeight: "h-[39px]",
      containerWidth: "w-[73px]",
    },
  ];

  return (
    <section className="w-full bg-[#07090d] border-t border-[#1e293b80] py-20">
      <div className="w-full mx-auto">
        <div className="flex flex-col items-center gap-16">
          <header className="w-full flex justify-center">
            <h2 className="[font-family:'Roboto',Helvetica] font-bold text-[10px] tracking-[4.00px] leading-[15px] whitespace-nowrap">
              <span className="text-sky-500">STACK TECNOLÓGICA</span>
            </h2>
          </header>

          <div className="w-full overflow-hidden py-12 relative">
            {/* Gradient Mask for smooth fade at edges */}
            <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-[#07090d] to-transparent z-10 pointer-events-none" />
            <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-[#07090d] to-transparent z-10 pointer-events-none" />
            
            <div className="flex w-max items-center gap-24 animate-marquee hover:[animation-play-state:paused]">
              {[...technologies, ...technologies, ...technologies].map((tech, index) => (
                <div
                  key={index}
                  className={`flex flex-col items-center justify-center gap-4 opacity-60 hover:opacity-100 transition-all duration-300 group cursor-pointer ${tech.containerWidth} min-h-[120px] rounded-none flex-shrink-0 mx-4`}
                >
                  <div className="h-[60px] flex items-center justify-center w-full">
                    <img
                      className={`${tech.imageWidth} ${tech.imageHeight} object-contain transition-all duration-500`}
                      style={{ filter: "brightness(0) saturate(100%) invert(94%) sepia(0%) saturate(0%) hue-rotate(189deg) brightness(91%) contrast(85%)" }} // Approximates #D9D9D9
                      onMouseEnter={(e) => (e.currentTarget.style.filter = "none")}
                      onMouseLeave={(e) => (e.currentTarget.style.filter = "brightness(0) saturate(100%) invert(94%) sepia(0%) saturate(0%) hue-rotate(189deg) brightness(91%) contrast(85%)")}
                      alt={tech.label}
                      src={tech.image}
                    />
                  </div>
                  <div className="[font-family:'JetBrains_Mono',Helvetica] font-bold text-[#D9D9D9] text-xs tracking-[1.20px] leading-4 whitespace-nowrap group-hover:text-sky-500 transition-colors duration-300">
                    {tech.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
