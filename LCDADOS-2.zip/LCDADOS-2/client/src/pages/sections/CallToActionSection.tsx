import { ArrowRightIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

const jobPostings = [
  {
    icon: "/figmaAssets/vector-18.svg",
    title: "Comerciais (comissão)",
    requirements: [
      "Foco em mercado B2B",
      "Comunicação clara e persuasiva",
      "Autonomia e proatividade",
    ],
  },
  {
    icon: "/figmaAssets/vector-13.svg",
    title: "Perfis técnicos (full-time, remoto)",
    requirements: [
      "Data Engineers & Scientists",
      "Full-stack Web Devs",
      "Foco total em qualidade e Peer Review",
    ],
  },
];

export const CallToActionSection = (): JSX.Element => {
  return (
    <section className="bg-[#0f1923] border-t border-[#1e293b80] w-full">
      <div className="max-w-full mx-auto px-[90px] py-24">
        <div className="flex flex-col gap-16">
          <header className="flex flex-col gap-2">
            <div className="[font-family:'JetBrains_Mono',Helvetica] font-normal text-[#359eff] text-[10px] tracking-[4.00px] leading-[15px]">
              RECRUTAMENTO
            </div>

            <h2 className="[font-family:'Roboto',Helvetica] font-extrabold text-slate-100 text-5xl tracking-[-1.20px] leading-[48px]">
              JUNTE-SE A NÓS
            </h2>

            <div className="max-w-2xl pt-2">
              <p className="[font-family:'Roboto',Helvetica] text-slate-400 font-thin text-[16px]">
                Estamos sempre à procura de pessoas talentosas para fazer parte
                da nossa equipa.
              </p>
            </div>
          </header>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {jobPostings.map((job, index) => (
              <Card key={index} className="bg-slate-900 border-slate-800 rounded-none transition-all duration-300 hover:border-sky-500/50 hover:bg-slate-900/80 group">
                <CardContent className="p-8">
                  <div className="flex flex-col gap-8">
                    <div className="flex items-start justify-between">
                      <div className="w-9 h-11 flex items-center justify-center transition-transform duration-300 group-hover:scale-110">
                        <img
                          src={job.icon}
                          alt="Job icon"
                          className="w-full h-full object-contain"
                        />
                      </div>

                      <Badge className="bg-[#0ea5e936] text-sky-500 hover:bg-[#0ea5e936] [font-family:'JetBrains_Mono',Helvetica] font-normal text-[10px] tracking-[0] leading-[15px] px-2 py-1 h-auto transition-all duration-300 group-hover:bg-sky-500 group-hover:text-white">
                        VAGA ABERTA
                      </Badge>
                    </div>

                    <h3 className="[font-family:'Roboto',Helvetica] font-bold text-slate-100 text-2xl leading-8 transition-colors duration-300 group-hover:text-sky-400">
                      {job.title}
                    </h3>

                    <ul className="flex flex-col gap-3">
                      {job.requirements.map((requirement, reqIndex) => (
                        <li key={reqIndex} className="flex items-center gap-2">
                          <div className="flex-shrink-0 w-[12.02px] h-3.5 flex items-center justify-center">
                            <img
                              src="/figmaAssets/vector-1.svg"
                              alt="Checkmark"
                              className="w-full h-full object-contain brightness-75 group-hover:brightness-100 transition-all duration-300"
                            />
                          </div>
                          <span className="[font-family:'Roboto',Helvetica] font-normal text-slate-400 text-sm leading-5 group-hover:text-slate-300 transition-colors duration-300">
                            {requirement}
                          </span>
                        </li>
                      ))}
                    </ul>

                    <button 
                      className="inline-flex items-center gap-2 self-start group/btn"
                      onClick={() => {
                        const element = document.getElementById("recrutamento");
                        if (element) element.scrollIntoView({ behavior: "smooth" });
                      }}
                    >
                      <span className="[font-family:'Roboto',Helvetica] font-bold text-[#d9b87f] text-xs tracking-[1.20px] leading-4 transition-all duration-300">
                        CANDIDATAR AGORA
                      </span>
                      <ArrowRightIcon className="w-[14.01px] h-[15.99px] text-[#d9b87f] transition-transform duration-300 group-hover/btn:translate-x-1" />
                    </button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
