import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useState, useEffect } from "react";
import oceanGif from "@assets/image_1768700902096.png";
import seaVideo from "@assets/image_1768699893636.png";

export const HeroSection = (): JSX.Element => {
  const [typedText, setTypedText] = useState("");
  const fullText = "GESTÃO DADOS";

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      setTypedText(fullText.slice(0, i));
      i++;
      if (i > fullText.length) clearInterval(interval);
    }, 100);
    return () => clearInterval(interval);
  }, []);

  const statusItems = [
    { label: "PROCESS_LOG:", value: "ACTIVE", valueColor: "text-green-400" },
    { label: "QUEUE:", value: "8,421 req/s", valueColor: "text-sky-500" },
  ];

  return (
    <section className="relative flex min-h-[600px] w-full items-center justify-center overflow-hidden px-4 md:px-0 pb-[80px] pt-[20px] bg-[#0b0e14]">
      {/* Animated Sea Background Video */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover opacity-[0.22]"
        >
          <source src={seaVideo} type="video/mp4" />
        </video>
        {/* Dark overlay to ensure text readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0f1923cc] via-[#0b0e1499] to-[#0b0e14]" />
      </div>

      <div className="absolute left-0 top-0 h-full w-full bg-[linear-gradient(90deg,rgba(255,255,255,0.03)_3%,rgba(255,255,255,0)_3%),linear-gradient(180deg,rgba(255,255,255,0.03)_3%,rgba(255,255,255,0)_3%)] opacity-40 z-[1]" />

      <div className="absolute -left-20 top-[25.00%] h-[32.00%] w-96 bg-[#0ea5e91a] blur-[60px]" />

      <div className="absolute -right-16 top-[46.92%] h-[32.00%] w-96 bg-[#359eff1a] blur-[60px]" />

      <div className="relative flex flex-col lg:flex-row w-full max-w-screen-xl items-start justify-center gap-12 py-0 z-10">
        <div className="relative flex flex-1 grow flex-col items-start justify-center w-full">
          <div className="relative flex w-full flex-col items-start">
            <div className="relative inline-flex flex-col items-start pb-6 pt-0">
              <Badge
                variant="outline"
                className="h-auto border-slate-700 bg-[#1e293b80] px-3 py-1"
              >
                <div className="relative h-2 w-2 bg-sky-500" />
                <span className="pl-2 [font-family:'JetBrains_Mono',Helvetica] text-[8px] md:text-[10px] font-normal leading-[15px] tracking-[1.00px] text-slate-400 select-text">
                  DATA ANALYTICS &amp; SOFTWARE ARCHITECTURE
                </span>
              </Badge>
            </div>
          </div>

          <div className="relative flex w-full flex-col items-start pb-6 pt-0">
            <div className="relative flex w-full flex-col items-start gap-2">
              <h1 className="relative mt-[-1.00px] flex w-fit items-center justify-center whitespace-normal md:whitespace-nowrap text-4xl md:text-7xl font-extrabold leading-tight md:leading-[72px] tracking-[-1.80px] text-slate-100 [font-family:'Roboto',Helvetica] select-text cursor-text min-h-[1em]">
                {typedText}
                <span className="animate-pulse ml-1 text-sky-500">|</span>
              </h1>

              <div className="relative flex flex-wrap w-fit items-center text-3xl md:text-[45px] leading-tight md:leading-[45px] tracking-[-1.12px] text-slate-100 [font-family:'Roboto',Helvetica] select-text cursor-text">
                <span className="font-medium">
                  e
                </span>
                <span className="hidden md:inline">&nbsp;</span>
                <span className="text-4xl md:text-7xl font-extrabold leading-tight md:leading-[72px] tracking-[-1.30px]">
                  SOFTWARE
                  <br className="hidden md:block" />
                  CUSTOMIZADO
                </span>
              </div>
            </div>
          </div>

          <div className="relative flex w-full max-w-[576px] flex-col items-start pb-10 pt-0">
            <div className="relative flex w-full flex-col items-start">
              <p className="relative mt-[-1.00px] flex items-center self-stretch font-light md:text-xl tracking-[0] text-slate-400 [font-family:'Roboto',Helvetica] select-text cursor-text text-[16px]">
                Soluções práticas para organizar e manipular a sua informação
                com precisão cirúrgica e escalabilidade.
              </p>
            </div>
          </div>

          <div className="relative flex flex-col md:flex-row w-full items-start md:items-center gap-4">
            <Button 
              className="w-full md:w-auto h-auto bg-[#ddb97d] border border-slate-700/50 rounded-none px-8 py-4 text-[#000000] hover:bg-[#ddb97d] hover:border-opacity-100 transition-all duration-300 cursor-pointer pointer-events-auto text-base font-bold leading-6 tracking-[1.60px] [font-family:'Roboto',Helvetica]"
              onClick={() => {
                const element = document.getElementById("contato");
                if (element) {
                  const headerOffset = 80;
                  const elementPosition = element.getBoundingClientRect().top;
                  const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                  window.scrollTo({ top: offsetPosition, behavior: "smooth" });
                }
              }}
            >
              EXPLORAR SOLUÇÕES
            </Button>

            <Button
              variant="outline"
              className="w-full md:w-auto h-auto border border-slate-700/50 bg-[#0f172a] rounded-none px-8 py-4 text-sky-500 hover:bg-[#0f172a] hover:border-sky-500 hover:border-opacity-100 transition-all duration-300 cursor-pointer pointer-events-auto"
              onClick={() => {
                const element = document.getElementById("como-trabalhamos");
                if (element) {
                  const headerOffset = 80;
                  const elementPosition = element.getBoundingClientRect().top;
                  const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                  window.scrollTo({ top: offsetPosition, behavior: "smooth" });
                }
              }}
            >
              <span className="whitespace-nowrap text-center text-base font-bold leading-6 tracking-[1.60px] text-sky-500 [font-family:'Roboto',Helvetica]">
                METODOLOGIA
              </span>
            </Button>
          </div>
        </div>

        <div className="hidden lg:flex relative flex-1 grow items-center justify-end">
          <Card className="relative w-[500px] max-w-[500px] border-slate-800 bg-[#ffffff05] p-4 backdrop-blur-[2px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(2px)_brightness(100%)] overflow-hidden rounded-none">
            <div className="absolute inset-0 z-0 opacity-40">
              <video
                autoPlay
                loop
                muted
                playsInline
                className="w-full h-full object-cover"
              >
                <source src={oceanGif} type="video/mp4" />
              </video>
            </div>
            <CardContent className="p-0 relative z-10">
              <div className="relative flex w-[466px] flex-col items-start justify-center">
                <div className="relative h-[466px] w-full">
                  <img
                    className="absolute left-0 top-[10.94%] h-[64.06%] w-full"
                    alt="Vector"
                    src="/figmaAssets/vector-27.svg"
                  />
                </div>
                <div className="absolute right-10 top-10 inline-flex flex-col items-start gap-2 border border-solid border-slate-700 bg-[#0f172ae6] p-4">
                  {statusItems.map((item, index) => (
                    <div
                      key={index}
                      className="relative inline-flex items-start justify-between"
                    >
                      <div className="inline-flex flex-col items-start">
                        <div className="relative mt-[-1.00px] flex w-fit items-center justify-center whitespace-nowrap text-[10px] leading-[15px] tracking-[0] text-sky-500 [font-family:'JetBrains_Mono',Helvetica]">
                          {item.label}
                        </div>
                      </div>

                      <div className="inline-flex flex-col items-start justify-center py-0 pl-4 pr-0">
                        <div className="inline-flex flex-1 grow flex-col items-start">
                          <div
                            className={`relative mt-[-1.00px] flex w-fit items-center justify-center whitespace-nowrap text-[10px] leading-[15px] tracking-[0] ${item.valueColor} [font-family:'JetBrains_Mono',Helvetica]`}
                          >
                            {item.value}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="absolute -left-[3px] -top-[3px] h-4 w-4 border-l-2 border-t-2 border-[#359eff]" />
              <div className="absolute -bottom-[3px] -right-[3px] h-4 w-4 border-b-2 border-r-2 border-sky-500" />
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};
