import { Button } from "@/components/ui/button";

const socialIcons = [
  {
    src: "/figmaAssets/vector-6.svg",
    alt: "Facebook",
    width: "w-[24.02px]",
    height: "h-7",
    imgWidth: "w-[72.86%]",
    imgHeight: "h-[69.44%]",
    imgTop: "top-[15.28%]",
    imgLeft: "left-[9.52%]",
  },
  {
    src: "/figmaAssets/vector-3.svg",
    alt: "Twitter",
    width: "w-[24.01px]",
    height: "h-[27.99px]",
    imgWidth: "w-[97.14%]",
    imgHeight: "h-[79.86%]",
    imgTop: "top-[8.33%]",
    imgLeft: "left-0",
    containerClass: "w-[56.02px] h-[31px]",
    innerClass: "h-[calc(100%_+_2px)] -top-0.5 left-8",
  },
  {
    src: "/figmaAssets/vector.svg",
    alt: "LinkedIn",
    width: "w-[24.02px]",
    height: "h-7",
    imgWidth: "w-[97.14%]",
    imgHeight: "h-[41.67%]",
    imgTop: "top-[29.17%]",
    imgLeft: "left-0",
    containerClass: "w-[56.02px] h-[31px]",
    innerClass: "h-[calc(100%_+_2px)] -top-0.5 left-8",
  },
];

const footerLinks = [
  { label: "PRIVACIDADE", href: "#" },
  { label: "TERMOS", href: "#" },
  { label: "COOKIES", href: "#" },
];

export const FooterSection = (): JSX.Element => {
  return (
    <footer className="flex flex-col items-start pt-[46.5px] pb-12 px-80 w-full bg-[#0f1923] border-t border-[#1e293b80]">
      <div className="flex flex-col max-w-screen-xl items-start gap-12 px-6 py-0 w-full">
        <div className="flex items-end justify-between w-full">
          <img
            className="w-[226px] h-[27px] object-cover"
            alt="LC Dados Logo"
            src="/figmaAssets/image-1-1.png"
          />

          <div className="inline-flex items-end gap-0">
            {socialIcons.map((icon, index) => (
              <div
                key={index}
                className={
                  icon.containerClass || "inline-flex flex-col items-start"
                }
              >
                {icon.innerClass ? (
                  <div
                    className={`inline-flex flex-col items-start ${icon.innerClass}`}
                  >
                    <div className="inline-flex items-start">
                      <div className={`relative ${icon.width} ${icon.height}`}>
                        <img
                          className={`absolute ${icon.imgWidth} ${icon.imgHeight} ${icon.imgTop} ${icon.imgLeft}`}
                          alt={icon.alt}
                          src={icon.src}
                        />
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="inline-flex flex-col items-start">
                    <div className="inline-flex items-start">
                      <div className={`relative ${icon.width} ${icon.height}`}>
                        <img
                          className={`absolute ${icon.imgWidth} ${icon.imgHeight} ${icon.imgTop} ${icon.imgLeft}`}
                          alt={icon.alt}
                          src={icon.src}
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-between w-full">
          <div className="inline-flex flex-col items-start">
            <p className="flex items-center justify-center w-fit mt-[-1.00px] [font-family:'Roboto',Helvetica] font-bold text-slate-500 text-[10px] tracking-[1.00px] leading-[15px] whitespace-nowrap">
              © 2024 LC DADOS. TODOS OS DIREITOS RESERVADOS. DESIGN BY
              ENGINEERING TEAM.
            </p>
          </div>

          <nav className="inline-flex items-start">
            {footerLinks.map((link, index) => (
              <div
                key={index}
                className={`inline-flex flex-col items-start ${
                  index > 0 ? "justify-center pl-6 pr-0 py-0" : ""
                }`}
              >
                <Button
                  variant="link"
                  className="h-auto p-0 mt-[-1.00px] text-slate-500 text-[10px] tracking-[1.00px] leading-[15px] [font-family:'Roboto',Helvetica] font-bold whitespace-nowrap hover:no-underline"
                  asChild
                >
                  <a href={link.href}>{link.label}</a>
                </Button>
              </div>
            ))}
          </nav>
        </div>
      </div>
    </footer>
  );
};
