import { Card, CardContent } from "@/components/ui/card";
import { useState, useRef } from "react";

const consultingServices = [
  {
    icon: "/figmaAssets/vector-19.svg",
    title: "Análise de Dados",
    description: "Limpeza, integração e visualização de dados para\ndecisões rápidas.",
  },
  {
    icon: "/figmaAssets/vector-22.svg",
    title: "Transformação de Excel em\nSoftware",
    description: "Convertemos modelos Excel complexos em\naplicações fiáveis e personalizadas (desktop ou\nweb).",
  },
  {
    icon: "/figmaAssets/vector-20.svg",
    title: "Gestão de Informação",
    description: "Criamos processos, modelos de dados e\ngovernança. Menos ficheiros soltos, mais controlo\ne rastreabilidade.",
  },
];

const SpotlightCard = ({ service }: { service: any }) => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [opacity, setOpacity] = useState(0);
  const cardRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;

    const rect = cardRef.current.getBoundingClientRect();
    setPosition({ x: e.clientX - rect.left, y: e.clientY - rect.top });
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setOpacity(1)}
      onMouseLeave={() => setOpacity(0)}
      className="flex-1 min-w-[389.33px] relative overflow-hidden bg-[#0f19230d] border border-solid border-slate-800/5 p-8 rounded-none transition-all duration-300 hover:bg-[#0f192399] hover:border-sky-500/70 group"
    >
      <div
        className="pointer-events-none absolute -inset-px transition duration-300"
        style={{
          background: `radial-gradient(100px circle at ${position.x}px ${position.y}px, rgba(14, 165, 233, 0.07), transparent 80%)`,
          opacity: opacity,
        }}
      />
      <div
        className="pointer-events-none absolute -inset-px border-2 border-sky-400 opacity-0 transition-opacity duration-200 group-hover:opacity-100 group-hover:animate-neon-glow-intense z-20"
        style={{
          maskImage: `radial-gradient(150px circle at ${position.x}px ${position.y}px, black, transparent)`,
          WebkitMaskImage: `radial-gradient(150px circle at ${position.x}px ${position.y}px, black, transparent)`,
        }}
      />
      <div className="relative z-10 flex flex-col gap-6">
        <div className="flex items-start">
          <div className="relative w-9 h-11">
            <img
              className="absolute w-full h-full object-contain"
              alt="Service icon"
              src={service.icon}
            />
          </div>
        </div>

        <div className="flex flex-col items-start gap-4">
          <h3 className="[font-family:'Roboto',Helvetica] font-bold text-slate-100 text-xl tracking-[0] leading-7 whitespace-pre-line">
            {service.title}
          </h3>
          <p className="[font-family:'Roboto',Helvetica] font-normal text-slate-400 text-sm tracking-[0] leading-[22.8px] whitespace-pre-line">
            {service.description}
          </p>
        </div>
      </div>
    </div>
  );
};

export const ConsultingSolutionsSection = (): JSX.Element => {
  return (
    <section className="py-24 bg-[#07090d] flex flex-col items-start w-full border-t [border-top-style:solid] border-[#1e293b80]">
      <div className="flex flex-col w-full items-start gap-16 py-0 px-[90px] mx-auto">
        <header className="flex flex-col items-start gap-4 w-full">
          <div className="w-full flex flex-col items-start">
            <p className="flex items-center justify-start w-full mt-[-1.00px] [font-family:'JetBrains_Mono',Helvetica] font-normal text-[#359eff] text-[10px] tracking-[4.00px] leading-[15px]">
              SERVIÇOS ESPECIALIZADOS
            </p>
          </div>

          <div className="w-full flex flex-col items-start">
            <h2 className="flex items-center justify-start w-full mt-[-1.00px] [font-family:'Roboto',Helvetica] font-extrabold text-5xl tracking-[-1.20px] leading-[48px]">
              <span className="text-slate-100 tracking-[-0.58px]">
                SOLUÇÕES DE&nbsp;
              </span>
              <span className="text-sky-500 tracking-[-0.58px]">
                CONSULTORIA
              </span>
            </h2>
          </div>
        </header>

        <div className="flex items-stretch justify-start gap-8 w-full overflow-x-auto pb-4">
          {consultingServices.map((service, index) => (
            <SpotlightCard key={index} service={service} />
          ))}
        </div>
      </div>
    </section>
  );
};
