import { MailIcon, MapPinIcon, PhoneIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

const contactInfo = [
  {
    icon: MailIcon,
    text: "geral@lcdados.pt",
  },
  {
    icon: MapPinIcon,
    text: "Lisboa, Portugal",
  },
  {
    icon: PhoneIcon,
    text: "+351 210 000 000",
  },
];

export const ContactFormSection = (): JSX.Element => {
  return (
    <section className="py-24 bg-[#07090d] flex flex-col items-center w-full border-t [border-top-style:solid] border-[#1e293b80]">
      <div className="flex flex-col lg:flex-row items-start justify-center gap-20 w-full px-[90px] max-w-full">
        <div className="flex flex-col items-start gap-8 flex-1 w-full lg:max-w-[480px]">
          <div className="flex flex-col items-start w-full">
            <h2 className="flex items-center justify-start w-full [font-family:'Roboto',Helvetica] font-extrabold text-4xl tracking-[0] leading-10">
              <span className="text-slate-100">VAMOS </span>
              <span className="text-sky-500 ml-2">CONVERSAR</span>
              <span className="text-slate-100">?</span>
            </h2>
          </div>

          <div className="flex flex-col items-start w-full">
            <p className="flex flex-col items-start justify-start w-full [font-family:'Roboto',Helvetica] text-slate-400 font-thin text-[16px] tracking-[0] leading-7">
              <span className="font-light text-[16px]">Diga-nos qual é o seu desafio com os dados.</span>
              <span className="font-light text-[16px]">A nossa equipa entrará em contacto num período máximo de 24 horas.</span>
            </p>
          </div>

          <div className="flex flex-col items-start gap-5 pt-3.5 w-full">
            {contactInfo.map((item, index) => {
              const IconComponent = item.icon;
              return (
                <div key={index} className="flex items-center w-full group cursor-pointer transition-colors duration-300 hover:text-white">
                  <div className="inline-flex flex-col items-start">
                    <div className="w-[24.02px] h-7 flex items-center justify-center">
                      <IconComponent className="w-4 h-4 text-slate-300 transition-colors duration-300 group-hover:text-sky-500" />
                    </div>
                  </div>
                  <div className="inline-flex flex-col items-start pl-4">
                    <span className="flex items-center justify-center [font-family:'Roboto',Helvetica] font-normal text-slate-300 text-base tracking-[0] leading-6 whitespace-nowrap group-hover:text-white transition-colors duration-300">
                      {item.text}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex flex-col items-start gap-4 flex-1 w-full max-w-[576px]">
          <div className="flex flex-col lg:flex-row items-start justify-center gap-4 w-full">
            <div className="flex flex-col items-start flex-1 w-full bg-[#0f1923] border border-solid border-slate-800 rounded-none transition-all duration-300 hover:border-slate-600 focus-within:border-sky-500">
              <Input
                placeholder="NOME"
                className="w-full bg-transparent border-0 rounded-none [font-family:'JetBrains_Mono',Helvetica] font-normal text-slate-400 text-sm placeholder:text-slate-600 focus-visible:ring-0 focus-visible:ring-offset-0 h-auto py-[18px] px-4"
              />
            </div>

            <div className="flex flex-col items-start flex-1 w-full bg-[#0f1923] border border-solid border-slate-800 rounded-none transition-all duration-300 hover:border-slate-600 focus-within:border-sky-500">
              <Input
                placeholder="EMAIL"
                className="w-full bg-transparent border-0 rounded-none [font-family:'JetBrains_Mono',Helvetica] font-normal text-slate-400 text-sm placeholder:text-slate-600 focus-visible:ring-0 focus-visible:ring-offset-0 h-auto py-[18px] px-4"
              />
            </div>
          </div>

          <div className="flex items-start justify-center w-full bg-[#0f1923] border border-solid border-slate-800 rounded-none transition-all duration-300 hover:border-slate-600 focus-within:border-sky-500">
            <Input
              placeholder="ASSUNTO"
              className="w-full bg-transparent border-0 rounded-none [font-family:'JetBrains_Mono',Helvetica] font-normal text-slate-400 text-sm placeholder:text-slate-600 focus-visible:ring-0 focus-visible:ring-offset-0 h-auto py-[18px] px-4"
            />
          </div>

          <div className="flex items-start justify-center w-full bg-[#0f1923] border border-solid border-slate-800 rounded-none transition-all duration-300 hover:border-slate-600 focus-within:border-sky-500">
            <Textarea
              placeholder="MENSAGEM"
              className="w-full min-h-[120px] bg-transparent border-0 rounded-none [font-family:'JetBrains_Mono',Helvetica] font-normal text-slate-400 text-sm placeholder:text-slate-600 focus-visible:ring-0 focus-visible:ring-offset-0 resize-none pt-4 px-4"
            />
          </div>

          <Button className="flex items-center justify-center w-full bg-sky-500 hover:bg-sky-600 h-auto px-0 py-4 rounded-none transition-all duration-300 hover:shadow-[0_0_20px_rgba(14,165,233,0.3)] hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.98]">
            <span className="[font-family:'Roboto',Helvetica] font-bold text-white text-base text-center tracking-[1.60px] leading-6 whitespace-nowrap">
              ENVIAR MENSAGEM
            </span>
          </Button>
        </div>
      </div>
    </section>
  );
};
