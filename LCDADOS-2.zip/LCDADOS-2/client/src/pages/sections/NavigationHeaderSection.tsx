import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";

const navigationItems = [
  { label: "Início", id: "inicio" },
  { label: "Consultoria", id: "solucoes" },
  { label: "Tecnologias", id: "tecnologias" },
  { label: "Recrutamento", id: "contato" },
];

export const NavigationHeaderSection = (): JSX.Element => {
  const [activeItem, setActiveItem] = useState("Início");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + 100;

      for (const item of navigationItems) {
        const element = document.getElementById(item.id);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveItem(item.label);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string, label: string) => {
    setActiveItem(label);
    setIsMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <header className="flex flex-col w-full items-start bg-[#0f1923f2] border-b border-[#ffffff0d] backdrop-blur-[6px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(6px)_brightness(100%)]">
      <div className="flex max-w-full h-20 items-center justify-between px-4 md:px-[90px] py-0 w-full mx-auto">
        <img
          className="w-[180px] md:w-[226px] h-auto object-cover cursor-pointer hover:opacity-80 transition-opacity"
          alt="Logo"
          src="/figmaAssets/image-1-1.png"
          onClick={() => scrollToSection("inicio", "Início")}
        />

        {/* Desktop Navigation */}
        <nav className="hidden md:inline-flex items-center h-full">
          {navigationItems.map((item, index) => (
            <button
              key={item.label}
              onClick={() => scrollToSection(item.id, item.label)}
              className={`inline-flex flex-col items-center justify-center px-1 h-full relative group cursor-pointer ${
                index > 0 ? "ml-8" : ""
              }`}
            >
              <span className={`[font-family:'Roboto',Helvetica] font-medium text-sm text-center tracking-[0] leading-5 whitespace-nowrap transition-colors ${
                activeItem === item.label ? "text-white" : "text-slate-400 group-hover:text-slate-200"
              }`}>
                {item.label}
              </span>
              {activeItem === item.label && (
                <div className="absolute w-full left-0 bottom-0 h-0.5 bg-[#d9b87f] transition-all duration-300" />
              )}
            </button>
          ))}
        </nav>

        {/* Desktop Button */}
        <div className="hidden md:block">
          <Button 
            className="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-none focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-sky-500 shadow h-auto bg-[#0f172a] border border-slate-700/50 hover:bg-[#0f172a] hover:border-sky-500 hover:border-opacity-100 px-6 py-2.5 cursor-pointer transition-all active:scale-95 text-[12px] font-medium pl-[12px] pr-[12px] pt-[5px] pb-[5px]"
            onClick={() => scrollToSection("contato", "Recrutamento")}
          >
            FALE CONNOSCO
          </Button>
        </div>

        {/* Mobile Menu Toggle */}
        <button 
          className="md:hidden p-2 text-slate-100"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden w-full bg-[#0f1923] border-b border-[#ffffff0d] py-4 px-4 flex flex-col gap-4">
          {navigationItems.map((item) => (
            <button
              key={item.label}
              onClick={() => scrollToSection(item.id, item.label)}
              className={`text-left py-2 px-4 rounded-md transition-colors ${
                activeItem === item.label ? "bg-slate-800 text-white" : "text-slate-400"
              }`}
            >
              {item.label}
            </button>
          ))}
          <Button 
            className="w-full bg-sky-500 hover:bg-sky-600 py-4 mt-2"
            onClick={() => scrollToSection("contato", "Recrutamento")}
          >
            FALE CONNOSCO
          </Button>
        </div>
      )}
    </header>
  );
};
