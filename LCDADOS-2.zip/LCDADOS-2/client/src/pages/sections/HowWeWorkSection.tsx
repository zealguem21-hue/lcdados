import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";

const workflowSteps = [
  {
    number: "01",
    title: "Diagnóstico e Auditoria",
    description:
      "Analisamos a estrutura atual e identificamos os pontos de fricção nos seus\ndados.",
  },
  {
    number: "02",
    title: "Desenho da Solução",
    description:
      "Criamos um blueprint técnico focado em eficiência, segurança e facilidade de uso.",
  },
  {
    number: "03",
    title: "Implementação Ágil",
    description:
      "Desenvolvimento iterativo com entregas contínuas e feedback constante do\ncliente.",
  },
  {
    number: "04",
    title: "Suporte e Evolução",
    description:
      "Monitorização contínua e ajustes proativos para garantir que a solução cresce\ncom a empresa.",
  },
];

const floatingCards = [
  {
    className: "w-[13.70%] h-[13.70%] top-[10.00%] left-[20.00%]",
    iconSrc: "/figmaAssets/vector-15.svg",
    iconClassName: "w-[72.86%] h-[62.50%] top-[18.75%] left-[13.57%]",
    iconWidth: "24.02px",
    iconHeight: "28px",
  },
  {
    className: "w-[10.96%] h-[10.96%] top-[15.00%] left-[74.04%]",
    iconSrc: "/figmaAssets/vector-14.svg",
    iconClassName: "w-[80.95%] h-[62.50%] top-[18.75%] left-[9.52%]",
    iconWidth: "24.02px",
    iconHeight: "28px",
  },
  {
    className: "w-[16.44%] h-[8.22%] top-[71.78%] left-[10.00%]",
    isText: true,
    text: "INPUT_FLOW",
  },
  {
    className: "w-[13.70%] h-[13.70%] top-[76.30%] left-[66.30%]",
    iconSrc: "/figmaAssets/vector-30.svg",
    iconClassName: "w-[91.67%] h-[59.03%] top-[18.75%] left-[4.17%]",
    iconWidth: "30px",
    iconHeight: "36px",
  },
];

const backgroundLines = [
  {
    className: "w-[70.00%] h-[70.00%] top-[15.00%] left-[15.00%]",
    src: "/figmaAssets/vector-26.svg",
  },
  {
    className: "w-[50.00%] h-[50.00%] top-[25.00%] left-[25.00%]",
    src: "/figmaAssets/vector-5.svg",
  },
  {
    className: "w-0 h-[10.00%] top-[15.00%] left-[50.00%]",
    src: "/figmaAssets/vector-16.svg",
  },
  {
    className: "w-[10.00%] h-0 top-[50.00%] left-[75.00%]",
    src: "/figmaAssets/vector-2.svg",
  },
  {
    className: "w-[10.00%] h-0 top-[50.00%] left-[15.00%]",
    src: "/figmaAssets/vector-10.svg",
  },
];

export const HowWeWorkSection = (): JSX.Element => {
  const [hoveredStep, setHoveredStep] = useState<string | null>(null);
  const [openStep, setOpenStep] = useState<string | null>(null);

  const toggleStep = (stepNumber: string) => {
    setOpenStep(openStep === stepNumber ? null : stepNumber);
  };

  return (
    <section className="flex flex-col items-start py-24 w-full bg-[#0f1923] border-t border-solid border-[#1e293b80]">
      <div className="flex flex-col lg:flex-row items-center justify-center gap-16 w-full mx-auto">
        <div className="flex flex-col items-start gap-4 flex-1">
          <div className="flex flex-col items-start w-full">
            <p className="flex items-center justify-center w-full mt-[-1.00px] [font-family:'JetBrains_Mono',Helvetica] font-normal text-sky-500 text-[10px] tracking-[4.00px] leading-[15px]">
              WORKFLOW
            </p>
          </div>

          <div className="flex flex-col items-start w-full">
            <h2 className="flex items-center justify-center w-full mt-[-1.00px] [font-family:'Roboto',Helvetica] font-normal text-transparent text-5xl tracking-[-1.20px] leading-[48px]">
              <span className="font-extrabold text-slate-100 tracking-[-0.58px]">
                COMO{" "}
              </span>
              <span className="font-extrabold text-sky-500 tracking-[-0.58px]">
                TRABALHAMOS
              </span>
            </h2>
          </div>

          <div className="flex flex-col items-start gap-8 pt-4 w-full">
            {workflowSteps.map((step) => (
              <div
                key={step.number}
                onMouseEnter={() => setHoveredStep(step.number)}
                onMouseLeave={() => setHoveredStep(null)}
                onClick={() => toggleStep(step.number)}
                className={`flex flex-col items-start w-full group cursor-pointer transition-opacity duration-300 ${
                  hoveredStep !== null && hoveredStep !== step.number ? "opacity-50" : "opacity-100"
                }`}
              >
                <div className="flex items-start gap-6 w-full">
                  <div className="flex w-12 h-12 items-center justify-center border border-solid border-slate-700 rounded-none transition-all duration-300 group-hover:border-[#359eff] group-hover:bg-[#359eff1a] group-hover:scale-105">
                    <span className="flex items-center justify-center [font-family:'JetBrains_Mono',Helvetica] font-bold text-[#359eff] text-xl text-center tracking-[0] leading-7 whitespace-nowrap">
                      {step.number}
                    </span>
                  </div>

                  <div className="inline-flex flex-col flex-1 items-start gap-2">
                    <div className="flex items-center justify-between w-full">
                      <h3 className="mt-[-1.00px] [font-family:'Roboto',Helvetica] font-bold text-slate-100 text-lg tracking-[0] leading-7 whitespace-nowrap transition-colors group-hover:text-sky-400">
                        {step.title}
                      </h3>
                      <div className={`transition-transform duration-300 text-slate-400 ${openStep === step.number ? "rotate-180" : "rotate-0"}`}>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <polyline points="6 9 12 15 18 9"></polyline>
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>

                <div 
                  className={`grid transition-all duration-300 ease-in-out w-full pl-18 ${
                    openStep === step.number ? "grid-rows-[1fr] opacity-100 mt-4" : "grid-rows-[0fr] opacity-0"
                  }`}
                >
                  <div className="overflow-hidden">
                    <p className="[font-family:'Roboto',Helvetica] font-normal text-slate-400 text-sm tracking-[0] leading-5 whitespace-pre-line group-hover:text-slate-300">
                      {step.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex h-[584px] items-center justify-center flex-1">
          <div className="absolute w-full h-full top-0 left-0 [background:radial-gradient(50%_50%_at_50%_50%,rgba(53,158,255,0.3)_0%,rgba(53,158,255,0)_70%)]" />

          <div className="flex items-center justify-center flex-1 self-stretch relative">
            {floatingCards.map((card, index) => (
              <Card
                key={index}
                className={`absolute ${card.className} flex items-center justify-center bg-[#ffffff08] border border-solid border-[#ffffff14] shadow-[0px_8px_32px_#0000004c] backdrop-blur-[6px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(6px)_brightness(100%)]`}
              >
                <CardContent className="p-0 flex items-center justify-center">
                  {card.isText ? (
                    <span className="[font-family:'JetBrains_Mono',Helvetica] font-normal text-slate-400 text-[8px] tracking-[0] leading-3 whitespace-nowrap">
                      {card.text}
                    </span>
                  ) : (
                    <div className="inline-flex flex-col items-start">
                      <div
                        className="relative"
                        style={{
                          width: card.iconWidth,
                          height: card.iconHeight,
                        }}
                      >
                        <img
                          className={`absolute ${card.iconClassName}`}
                          alt="Icon"
                          src={card.iconSrc}
                        />
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}

            <div className="absolute w-full h-full top-0 left-0 opacity-20">
              {backgroundLines.map((line, index) => (
                <img
                  key={index}
                  className={`absolute ${line.className}`}
                  alt="Vector"
                  src={line.src}
                />
              ))}
            </div>

            <Card className="flex-col w-48 h-48 relative flex items-center justify-center bg-[#ffffff08] border border-solid border-[#ffffff14] shadow-[0px_8px_32px_#0000004c] backdrop-blur-[6px] backdrop-brightness-[100%] [-webkit-backdrop-filter:blur(6px)_brightness(100%)]">
              <CardContent className="p-0 flex flex-col items-center justify-center relative w-full h-full">
                <div className="absolute w-[calc(100%_-_2px)] h-[calc(100%_-_2px)] top-px left-px bg-[#3b82f61a]" />

                <div className="relative w-12 h-14">
                  <div className="inline-flex flex-col items-start relative top-[-5px]">
                    <div className="relative w-12 h-[58px]">
                      <img
                        className="absolute w-full h-[79.31%] top-[8.62%] left-0"
                        alt="Database icon"
                        src="/figmaAssets/vector-3.svg"
                      />
                    </div>
                  </div>
                </div>

                <div className="inline-flex flex-col items-start">
                  <span className="flex items-center justify-center mt-[-1.00px] [font-family:'JetBrains_Mono',Helvetica] font-bold text-[#ffffffe6] text-[10px] tracking-[2.00px] leading-[15px] whitespace-nowrap">
                    CORE DATA
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};
