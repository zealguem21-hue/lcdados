import { CallToActionSection } from "./sections/CallToActionSection";
import { ConsultingSolutionsSection } from "./sections/ConsultingSolutionsSection";
import { ContactFormSection } from "./sections/ContactFormSection";
import { FooterSection } from "./sections/FooterSection";
import { HeroSection } from "./sections/HeroSection";
import { HowWeWorkSection } from "./sections/HowWeWorkSection";
import { JoinUsSection } from "./sections/JoinUsSection";
import { NavigationHeaderSection } from "./sections/NavigationHeaderSection";

export const ElementLight = (): JSX.Element => {
  return (
    <div className="flex flex-col w-full bg-[#0f1923] overflow-x-hidden">
      <div className="fixed top-0 left-0 right-0 z-50 w-full">
        <NavigationHeaderSection />
      </div>
      <div className="pt-20"> {/* Offset for fixed header */}
        <div id="inicio" className="mt-0"><HeroSection /></div>
        <div id="solucoes" className="px-0"><ConsultingSolutionsSection /></div>
        <div id="como-trabalhamos" className="px-4 md:px-[90px]"><HowWeWorkSection /></div>
        <div id="tecnologias" className="px-0"><JoinUsSection /></div>
        <div id="cta" className="px-4 md:px-[90px]"><CallToActionSection /></div>
        <div id="contato"><ContactFormSection /></div>
        <div className="px-4 md:px-[90px]"><FooterSection /></div>
      </div>
    </div>
  );
};
